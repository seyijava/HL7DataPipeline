package com.bigdataconcept.bigdata.healthcare.hl7.generator.hL7Messagegenerator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HL7MessageGeneratorApplication {

	public static void main(String[] args) {
		SpringApplication.run(HL7MessageGeneratorApplication.class, args);
	}

}
